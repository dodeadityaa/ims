/*
SQLyog Professional v12.4.3 (64 bit)
MySQL - 10.1.30-MariaDB : Database - db_bank
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`db_bank` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `db_bank`;

/*Table structure for table `tb_nasabah` */

DROP TABLE IF EXISTS `tb_nasabah`;

CREATE TABLE `tb_nasabah` (
  `no_rek` int(11) NOT NULL,
  `nama_nasabah` varchar(30) DEFAULT NULL,
  `no_telp` varchar(13) DEFAULT NULL,
  `alamat` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`no_rek`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tb_nasabah` */

insert  into `tb_nasabah`(`no_rek`,`nama_nasabah`,`no_telp`,`alamat`) values 
(111,'Dode','081253416381','Gianyar'),
(112,'Abhi','087263514223','Tabanan'),
(113,'Arya','085765321456','Denpasar'),
(114,'Dewaadi','087612534661','Denpasar'),
(115,'Nana','081726354596','Denpasar'),
(116,'Dessy','088346552517','Denpasar'),
(117,'Ratih','081658366977','Denpasar'),
(118,'Rizky','085873966255','Badung'),
(119,'Sav','083573282840','Badung');

/*Table structure for table `tb_transaksi` */

DROP TABLE IF EXISTS `tb_transaksi`;

CREATE TABLE `tb_transaksi` (
  `id_transaksi` int(11) NOT NULL,
  `no_rek` int(11) DEFAULT NULL,
  `tgl_transaksi` date DEFAULT NULL,
  `total_transaksi` int(11) DEFAULT NULL,
  `status` enum('tidak valid','valid') DEFAULT NULL,
  PRIMARY KEY (`id_transaksi`),
  KEY `nasabah` (`no_rek`),
  CONSTRAINT `nasabah` FOREIGN KEY (`no_rek`) REFERENCES `tb_nasabah` (`no_rek`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tb_transaksi` */

insert  into `tb_transaksi`(`id_transaksi`,`no_rek`,`tgl_transaksi`,`total_transaksi`,`status`) values 
(1,111,'2018-05-28',25000,'valid');

/*Table structure for table `tb_transaksi_bank` */

DROP TABLE IF EXISTS `tb_transaksi_bank`;

CREATE TABLE `tb_transaksi_bank` (
  `id_transaksi_bank` int(11) NOT NULL AUTO_INCREMENT,
  `id_transaksi` int(11) DEFAULT NULL,
  `no_rek` int(11) DEFAULT NULL,
  `tgl_transaksi` date DEFAULT NULL,
  `total_transaksi` int(11) DEFAULT NULL,
  `status` enum('Valid','Tidak Valid') DEFAULT NULL,
  PRIMARY KEY (`id_transaksi_bank`),
  KEY `trans` (`id_transaksi`),
  CONSTRAINT `trans` FOREIGN KEY (`id_transaksi`) REFERENCES `tb_transaksi` (`id_transaksi`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `tb_transaksi_bank` */

insert  into `tb_transaksi_bank`(`id_transaksi_bank`,`id_transaksi`,`no_rek`,`tgl_transaksi`,`total_transaksi`,`status`) values 
(1,1,111,'2018-05-28',25000,'Valid');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
