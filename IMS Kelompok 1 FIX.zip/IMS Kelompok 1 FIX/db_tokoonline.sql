/*
SQLyog Professional v12.4.3 (64 bit)
MySQL - 10.1.30-MariaDB : Database - db_tokoonline
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`db_tokoonline` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `db_tokoonline`;

/*Table structure for table `tb_barang` */

DROP TABLE IF EXISTS `tb_barang`;

CREATE TABLE `tb_barang` (
  `id_barang` int(11) NOT NULL,
  `nama_barang` varchar(50) DEFAULT NULL,
  `stok` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_barang`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tb_barang` */

insert  into `tb_barang`(`id_barang`,`nama_barang`,`stok`) values 
(1,'Cola',11),
(2,'Chitos',20),
(3,'Aqua',5),
(4,'Club',7),
(5,'Chitato',18),
(6,'Piatos',9);

/*Table structure for table `tb_det_transaksi` */

DROP TABLE IF EXISTS `tb_det_transaksi`;

CREATE TABLE `tb_det_transaksi` (
  `id_det_transaksi` int(11) NOT NULL AUTO_INCREMENT,
  `id_transaksi` int(11) DEFAULT NULL,
  `id_barang` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_det_transaksi`),
  KEY `id_barang` (`id_barang`),
  KEY `id_transaksi` (`id_transaksi`),
  CONSTRAINT `tb_det_transaksi_ibfk_1` FOREIGN KEY (`id_barang`) REFERENCES `tb_barang` (`id_barang`),
  CONSTRAINT `tb_det_transaksi_ibfk_2` FOREIGN KEY (`id_transaksi`) REFERENCES `tb_transaksi` (`id_transaksi`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `tb_det_transaksi` */

insert  into `tb_det_transaksi`(`id_det_transaksi`,`id_transaksi`,`id_barang`) values 
(1,1,1);

/*Table structure for table `tb_pembeli` */

DROP TABLE IF EXISTS `tb_pembeli`;

CREATE TABLE `tb_pembeli` (
  `id_pembeli` int(11) NOT NULL,
  `nama_pembeli` varchar(30) DEFAULT NULL,
  `no_telp` varchar(13) DEFAULT NULL,
  `alamat` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_pembeli`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tb_pembeli` */

insert  into `tb_pembeli`(`id_pembeli`,`nama_pembeli`,`no_telp`,`alamat`) values 
(1,'Dode','08786198612','Gianyar'),
(2,'Abhi','085143748567','Tabanan'),
(3,'Arya','0873254625443','Denpasar'),
(4,'Dewaadi','081645324271','Denpasar'),
(5,'Nana','08164782437','Denpasar'),
(6,'Dessy','0817453273644','Denpasar'),
(7,'Ratih','0873537625365','Badung'),
(8,'Rizky','087353543523','Badung'),
(9,'Sav','0886535424316','Badung');

/*Table structure for table `tb_transaksi` */

DROP TABLE IF EXISTS `tb_transaksi`;

CREATE TABLE `tb_transaksi` (
  `id_transaksi` int(11) NOT NULL,
  `id_pembeli` int(11) DEFAULT NULL,
  `no_rek` int(11) DEFAULT NULL,
  `tgl_transaksi` date DEFAULT NULL,
  `total_transaksi` int(11) DEFAULT NULL,
  `status` enum('Valid','Tidak Valid') DEFAULT NULL,
  PRIMARY KEY (`id_transaksi`),
  KEY `id_pembeli` (`id_pembeli`),
  CONSTRAINT `tb_transaksi_ibfk_2` FOREIGN KEY (`id_pembeli`) REFERENCES `tb_pembeli` (`id_pembeli`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tb_transaksi` */

insert  into `tb_transaksi`(`id_transaksi`,`id_pembeli`,`no_rek`,`tgl_transaksi`,`total_transaksi`,`status`) values 
(1,1,111,'2018-05-27',25000,'Valid');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
