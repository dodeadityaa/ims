import pymysql
import time

conn = pymysql.connect(host='localhost', port=3306, user='root', passwd='', db='db_tokoonline')
cinn = pymysql.connect(host='localhost', port=3306, user='root', passwd='', db='db_intergrasi')
cann = pymysql.connect(host='localhost', port=3306, user='root', passwd='', db='db_bank')

cur = conn.cursor()
cir = cinn.cursor()
car = cann.cursor()

try:
    sistem = True
    while sistem:
        print("---- Selamat Datang Di Intergrasi Kelompok 1 ----")
        print("------------ pilih menu di bawah ini -----------")
        sistem = False

    menu = int(input("Masukkan input 1 insert, 2 update :"))


    if menu == 1:
        cur.execute("select max(id_transaksi) from tb_transaksi")
        maxdatatransaksi = cur.fetchone()
        # untuk mengecek 1 data tb_transaksi di db_tokoonline

        lanjut = True
        while lanjut:
            cur.execute("select *from tb_transaksi")
            toko = cur.fetchall()
            # untuk mengecek semua data di tb_transaksi di db_tokoonline
            cir.execute("select *from tb_transaksi")
            intergrasi = cir.fetchall()
            # untuk mengecek semua data di tb_transaksi di db_integrasi
            lanjut = False
        if len(toko)> len(intergrasi):
            print("ada transaksi")
            cur.execute("select id_transaksi, id_pembeli, no_rek, total_transaksi from tb_transaksi where id_transaksi='%s'" % (maxdatatransaksi))
            for row in cur.fetchall():
                id_transaksi, id_pembeli, no_rek, total_transaksi = row
                cir.execute("insert into tb_transaksi (id_transaksi, id_pembeli, no_rek, tgl_transaksi, total_transaksi, status) VALUES ('%s','%s', '%s', DATE(NOW()), '%s', 'Tidak Valid')" % (id_transaksi, id_pembeli, no_rek, total_transaksi))
                cinn.commit()
                # untuk memasukan data dari tb_transaksi tokoonline ke  tb_transaksi integrasi
                print("suksesss")


    cur.close()
    conn.close()
    cir.close()
    cinn.close()

    if menu == 2:
        update = True
        while update:
            print("Update dari bank ke toko")
            car.execute("select id_transaksi from tb_transaksi_bank where status = 'Valid'")
            bank = car.fetchone()
            #untuk mengecek 1 data di tb_transaksi db_bank yang berstatus valid
            print(bank)

            sql = """update tb_transaksi set status='Valid' where id_transaksi='%s'""" % (bank)
            cir.execute(sql)
            cinn.commit()
            #untuk menjalankan update status valid di tb_transaksi di db_integrasi
            print("sukses Update")
            update = False

except:
    print("ERROR")