import pymysql as sistem
import time as waktu

conn = sistem.connect(host='localhost', port=3306, user='root', passwd='', db='db_tokoonline')
cinn = sistem.connect(host='localhost', port=3306, user='root', passwd='', db='db_intergrasi')
curs = conn.cursor()
cir = cinn.cursor()

try :
    sistem = True
    while sistem:
        print("---- Selamat Datang Di Toko Online Kelompok 1 ----")
        print("------------ pilih menu di bawah ini -----------")

        menu = int(input("Masukkan input 1 insert, 2 update :"))


        if menu== 1:
            lanjut = True
            while lanjut:
                id_transaksi = int(input("Masukkan Id    :"))
                no_rek = int(input("Masukkan NO REK    :"))
                id_barang = int(input("masukan Id Barang :"))
                id_pembeli = int(input("Masukkan Pembeli  :"))
                total_transaksi = int(input("Masukkan Total  :"))
                #Untuk menginputkan id, no_rek, id_barang, id_pembeli, total_transaksi

                sql = """insert into tb_transaksi(id_transaksi, id_pembeli, no_rek, tgl_transaksi, total_transaksi, status)
                        values (%s, %s, %s, DATE(NOW()),%s,'Tidak Valid')""" % (id_transaksi, id_pembeli, no_rek, total_transaksi)
                data = """insert into tb_det_transaksi(id_transaksi,id_barang)
                        values (%s, %s)""" % (id_transaksi,id_barang)
                print("Berhasil Menginputkan")

                curs.execute(sql)
                #untuk mengexecute sql yang terdapat insert ke tb_transaksi di toko online
                curs.execute(data)
                #untuk mengexecute data yang terdapat insert ke tb_det_transaksi di toko online
                conn.commit()
                lanjut = False

        if menu == 2:
            update = True
            while update:
                print("Update dari Intergrasi ke Toko")
                cir.execute("select id_transaksi from tb_transaksi where status = 'valid'")
                intergrasi = cir.fetchone()
                #untuk mengecek id_transaksi yang sudah valid di db_integrasi tb_transaksi
                print(intergrasi)

                curs.execute("update tb_transaksi set status='Valid' where id_transaksi='%s'" % (intergrasi))
                conn.commit()
                # untuk mengexecute update valid di tb_transaksi di db_tokoonline
                print("suksesss lagi")
                update = False

except:
    print("ERROR")