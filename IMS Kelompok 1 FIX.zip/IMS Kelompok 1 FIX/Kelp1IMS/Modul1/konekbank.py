import pymysql
import time

conn = pymysql.connect(host='localhost', port=3306, user='root', passwd='', db='db_intergrasi')
cinn = pymysql.connect(host='localhost', port=3306, user='root', passwd='', db='db_bank')

cur = conn.cursor()
cir = cinn.cursor()

try:
    cur.execute("select max(id_transaksi) from tb_transaksi")
    maxdatatransaksi = cur.fetchone()

    lanjut = True
    while lanjut:
        cur.execute("select *from tb_transaksi")
        intergrasi = cur.fetchall()
        #untuk mengecek semua data di tb_transaksi integrasi
        cir.execute("select *from tb_transaksi")
        bank = cir.fetchall()
        # untuk mengecek semua data di tb_transaksi bank
        lanjut = False

    if len(intergrasi)> len(bank):
        print("ada transaksi masuk bank")
        cur.execute("select id_transaksi, no_rek, total_transaksi from tb_transaksi where id_transaksi='%s'" % (maxdatatransaksi))
        for row in cur.fetchall():
            id_transaksi, no_rek, total_transaksi = row
            cir.execute("insert into tb_transaksi (id_transaksi, no_rek, tgl_transaksi, total_transaksi, status) VALUES ('%s', '%s', DATE(NOW()), '%s', 'valid')" % (id_transaksi, no_rek, total_transaksi))
            cinn.commit()
            #untuk mengexecute insert tb_transaksi integrasi ke tb_integrasi bank dan merubah status menjadi valid
    print("suksesss")
    # cur.close()
    # conn.close()
    # cir.close()
    # cinn.close()

    cir.execute("select max(id_transaksi) from tb_transaksi")
    maxdatatransaksi1 = cir.fetchone()

    lanjut = True
    while lanjut:
        cir.execute("select *from tb_transaksi")
        bank = cir.fetchall()
        # untuk mengecek semua data di tb_transaksi integrasi
        cir.execute("select *from tb_transaksi_bank")
        bankk = cir.fetchall()
        # untuk mengecek semua data di tb_transaksi bank
        lanjut = False

    if len(bank) > len(bankk):
        print("ada transaksi masuk bank lagi")
        cir.execute("select id_transaksi, no_rek, total_transaksi, status from tb_transaksi where id_transaksi='%s'" % (maxdatatransaksi1))
        for row1 in cir.fetchall():
            id_transaksi, no_rek, total_transaksi, status = row1
            cir.execute( "insert into tb_transaksi_bank(id_transaksi, no_rek, tgl_transaksi, total_transaksi, status) VALUES ('%s', '%s', DATE(NOW()), '%s', '%s')" % (id_transaksi, no_rek, total_transaksi, status))
            cinn.commit()
            # untuk mengexecute insert tb_transaksi bank ke tb_transaksi_bank bank dan merubah status menjadi valid
    print("suksesss")
    cir.close()
    cinn.close()
except:
    print("ERROR")