import json
import pymysql

cinn = pymysql.connect(host='localhost', port=3306, user='root', passwd='', db='db_bank')
cir  = cinn.cursor()
try:
    modul2 = True
    while modul2:
        print("---- Selamat Datang Di Bank Kelompok 1 ----")
        print("------------ pilih menu di bawah ini -----------")
        menu = int(input("Masukkan 0:"))

        with open("bank_json.json", "w", encoding='utf-8')as outfile:
        #untuk memulis ke dalam file json toko_json
            try:
                data = json.load(outfile)
            except:
                data = []

        if menu == 0:
            print("Insert Bank")


            def insertbank(id_transaksi):
                #fungsi untuk membaca paramenter inserttoko
                list_data = []
                with open("bank_json.json", "r", encoding='utf-8')as outfile:
                #untuk membaca file json toko_json
                    try:
                        databank = json.load(outfile)
                    except:
                        databank = []
                new_entry = {'id_transaksi': id_transaksi, 'status': 'valid', 'flag': 'update'}
                #untuk memasukan data ke json
                list_data.append(new_entry)
                with open("bank_json.json", "w", encoding='utf-8')as outfile:
                #untuk membaca file json toko_json
                    json.dump(databank + list_data, outfile, indent=4)
            buka = open("toko_json.json", "r")
            data = json.load(buka)
            for row in data:
                if row['flag'] == 'insert':
                    print("Masuk Data Toko Ke Bank")
                    id_transaksi = row['id_transaksi']
                    no_rek = row['no_rek']
                    total_transaksi = row['total_transaksi']
                    print("pelanggan")
                    #mencetak tulisan
                    cir.execute("insert into tb_transaksi (id_transaksi, no_rek, tgl_transaksi, total_transaksi) VALUES ('%s', '%s', DATE(NOW()), '%s')" % (id_transaksi, no_rek, total_transaksi))
                    cinn.commit()
                    #untuk menjalankan execute insert
                    cir.execute("update tb_transaksi set status='Valid' where id_transaksi='%s'" % (id_transaksi))
                    cinn.commit()
                    #untuk mengupdate status valid di setiap transaksi di tb_transaksi
                    cir.execute("insert into tb_transaksi_bank (id_transaksi, no_rek, tgl_transaksi, total_transaksi) VALUES ('%s', '%s',  DATE(NOW()), '%s')" % (id_transaksi, no_rek, total_transaksi))
                    cinn.commit()
                    cir.execute("update tb_transaksi_bank set status='Valid' where id_transaksi='%s'" % (id_transaksi))
                    cinn.commit()
                    #untuk mengupdate status valid di setiap transaksi di tb_transaksi_bank

                    insertbank(id_transaksi)

                    openfile = open("toko_json.json", "r+")
                    data = json.load(openfile)
                    #untuk membuka file json dan melakukan update data
                    for row in data:
                        row['flag']='execute'
                        openfile.seek(0)
                        json.dump(data, openfile, indent=4)
                        openfile.truncate()
                    print("suksess")
                    #mencetak tulisan

except :
    print("Error Klee")
    # untuk mencetak tulisan jika terjadi kesalahan