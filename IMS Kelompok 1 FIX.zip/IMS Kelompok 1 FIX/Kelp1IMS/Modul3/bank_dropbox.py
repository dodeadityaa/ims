import json
import pymysql
import dropbox
import pathlib

cinn = pymysql.connect(host='localhost', port=3306, user='root', passwd='', db='db_bank')
cir  = cinn.cursor()
try:
    modul2 = True
    while modul2:
        print("---- Selamat Datang Di Bank Kelompok 1 ----")
        print("------------ pilih menu di bawah ini -----------")
        menu = int(input("Masukkan 0:"))

        downloadd = pathlib.Path("C:/Users/Dode/PycharmProjects/Kelp1IMS/Modul3")
        # untuk menentukan alamat melatakan file json yang didownload
        buka = "toko_json.json"
        masuk = downloadd / buka
        dropdownload = dropbox.Dropbox("9EXUZ0tRCwAAAAAAAAAADFCMfVabePA38B8cUt6HZc2Tq7dGX_5fAMKlv30rJoIm")
        dropdownload.files_download_to_file(masuk, "/Aplikasi/toko_json.json")
        # untuk mendownload file json
        with open("bank_json.json", "w", encoding='utf-8')as outfile:
        #untuk menulis file json bank_json
            try:
                data = json.load(outfile)
                # untuk memgambil file json bank_json
            except:
                data = []
                # array data

        if menu == 0:
            print("Insert Bank")
            def insertbank(id_transaksi):
                list_data = []
                with open("bank_json.json", "r", encoding='utf-8')as outfile:
                # untuk membaca file json bank_json
                    try:
                        databank = json.load(outfile)
                    except:
                        databank = []
                new_entry = {'id_transaksi': id_transaksi, 'status': 'valid', 'flag': 'update'}
                # untuk memasukan data ke json
                list_data.append(new_entry)
                with open("bank_json.json", "w", encoding='utf-8')as outfile:
                    json.dump(databank + list_data, outfile, indent=4)
                # untuk membuka file json bank_json

            buka = open("toko_json.json", "r")
            data = json.load(buka)
            # membuka file json
            for row in data:
                if row['flag'] == 'insert':
                    #mengecek kondisi data
                    print("Masuk Data Toko Ke Bank")
                    # mencetakan tulisan
                    id_transaksi = row['id_transaksi']
                    no_rek = row['no_rek']
                    # mengambil no_rek dalam row json
                    total_transaksi = row['total_transaksi']
                    # mengambil total_transaksi dalam row json
                    print("pelanggan")
                    cir.execute("insert into tb_transaksi (id_transaksi, no_rek, tgl_transaksi, total_transaksi) VALUES ('%s', '%s', DATE(NOW()), '%s')" % (id_transaksi, no_rek, total_transaksi))
                    #melakukan insert data ke tb_transaksi
                    cinn.commit()
                    cir.execute("update tb_transaksi set status='Valid' where id_transaksi='%s'" % (id_transaksi))
                    #melakukan update data tb_transaksi
                    cinn.commit()
                    cir.execute("insert into tb_transaksi_bank (id_transaksi, no_rek, tgl_transaksi, total_transaksi) VALUES ('%s', '%s',  DATE(NOW()), '%s')" % (id_transaksi, no_rek, total_transaksi))
                    #melakukan insert data ke tb_transaksi_bank
                    cinn.commit()
                    cir.execute("update tb_transaksi_bank set status='Valid' where id_transaksi='%s'" % (id_transaksi))
                    #melakukan updata data tb_transaksi bank
                    cinn.commit()

                    insertbank(id_transaksi)

                    openfile = open("toko_json.json", "r+")
                    data = json.load(openfile)
                    # untuk membuka file json dan melakukan update data
                    for row in data:
                        row['flag']='execute'
                        #mengecek kondisi data
                        openfile.seek(0)
                        json.dump(data, openfile, indent=4)
                        openfile.truncate()
                    print("suksess")

                    drop = dropbox.Dropbox("9EXUZ0tRCwAAAAAAAAAADFCMfVabePA38B8cUt6HZc2Tq7dGX_5fAMKlv30rJoIm");
                    # untuk mengisi token dropbox
                    with open("bank_json.json", "rb") as toko_dropbox:
                    # untuk membaca binary file json toko_json
                        drop.files_upload(toko_dropbox.read(), "/Aplikasi/bank_json.json",mode=dropbox.files.WriteMode("overwrite"));
                        # untuk mengupload data ke dropbox
                        print("berhasil Upload data bank_json ke Dropbox")
                        # untuk mencetak tulisan

except :
    print("Error Klee")