import dropbox
import pathlib
import pymysql
import json
conn = pymysql.connect(user="root", host="localhost", database="db_tokoonline")
cur = conn.cursor()

try:
    modul2 = True
    while modul2:
        print("-----    selamat datang di kelompok 1    -----")
        print("-------- pilih menu di bawah ini  ------------")

        menu = int(input(" Menu pilih 1 insert atau 2 update :"))

        with open("toko_json.json", "w", encoding='utf-8')as outfile:
            #untuk memulis ke dalam file json toko_json
            try:
                data = json.load(outfile)
            except:
                data = []
        if menu == 1:
            def inserttoko(id_transaksi, id_pembeli, no_rek, tgl_transaksi, total_transaksi, status):
                #fungsi untuk membaca paramenter inserttoko
                list_data = []
                with open("toko_json.json", "r", encoding='utf-8')as outfile:
                    #untuk membaca file json toko_json
                    try:
                        data = json.load(outfile)
                    except:
                        data = []
                new_entry = {'id_transaksi': id_transaksi, 'id_pembeli': id_pembeli, 'no_rek': no_rek,
                             'tanggal': str(tgl_transaksi), 'total_transaksi': total_transaksi, 'status': status,
                             'flag': 'insert'}
                #untuk memasukan data ke json
                list_data.append(new_entry)
                with open("toko_json.json", "w", encoding='utf-8')as outfile:
                #untuk membaca file json toko_json
                    json.dump(data + list_data, outfile, indent=4)
            print("insert data ke JSON")
            #untuk memunculkan output tulisan ke program
            lanjut = True
            #untuk membuat perulangan
            while lanjut:
            #melakukan perulangan
                cur.execute("select max(id_transaksi) from tb_transaksi")
                #untuk mengambil data pada id_transaksi di tb_transaksi
                maxdatatransaksi = cur.fetchone()
                #untuk mengambil data
                print(maxdatatransaksi)
                #untuk mencetak data maxdatatransaksi
                cur.execute("select *from tb_transaksi")
                #untuk menjalankan data dari tb_transaksi
                toko = cur.fetchall()
                #untuk mengambil semua baris data pada toko
                print(toko)
                #untuk mencetak data toko
                lanjut = False
                #untuk memberhentikan perulangan

                with open("toko_json.json", "r", encoding='utf-8')as outfile:
                #untuk membaca file json toko_json
                    try:
                        data = json.load(outfile)
                    #untuk mencegah program langsung keluar
                    except:
                        data = []
                    if (len(toko) > len(data)):
                    #untuk mengecek pajang data toko dengan data
                        print("Terdapat Penambahan Transaksi pada Toko")
                        #untuk memcetak tulisan
                        cur.execute("select id_transaksi, id_pembeli, no_rek, tgl_transaksi, total_transaksi, status from tb_transaksi where id_transaksi='%s'" % (maxdatatransaksi))
                        #untukk mengambil data pada tb_transaksi
                        for row1 in cur.fetchall():
                        #untuk mengambil semua baris data
                            id_transaksi, id_pembeli, no_rek, tgl_transaksi, total_transaksi, status = row1
                            inserttoko(id_transaksi, id_pembeli, no_rek, tgl_transaksi, total_transaksi, status)
                            print("suksess")
                            #untuk mencetak tulisan
                            drop = dropbox.Dropbox("9EXUZ0tRCwAAAAAAAAAADFCMfVabePA38B8cUt6HZc2Tq7dGX_5fAMKlv30rJoIm");
                            #untuk mengisi token dropbox
                            with open("toko_json.json", "rb") as toko_dropbox:
                            #untuk membaca binary file json toko_json
                                drop.files_upload(toko_dropbox.read(), "/Aplikasi/toko_json.json", mode=dropbox.files.WriteMode("overwrite"));
                                #untuk mengupload data ke dropbox
                                print("berhasil Upload data toko_json ke Dropbox")
                                #untuk mencetak tulisan

        if menu == 2:
            downloadd = pathlib.Path("C:/Users/Dode/PycharmProjects/Kelp1IMS/Modul3")
            #untuk menentukan alamat melatakan file json yang didownload
            buka = "bank_json.json"
            masuk = downloadd / buka
            dropdownload = dropbox.Dropbox("9EXUZ0tRCwAAAAAAAAAADFCMfVabePA38B8cUt6HZc2Tq7dGX_5fAMKlv30rJoIm")
            dropdownload.files_download_to_file(masuk, "/Aplikasi/bank_json.json")
            #untuk mendownload file json
            def updatestatustoko():
                bukajson = open("bank_json.json", "r+")
                data = json.load(bukajson)
                #untuk membuka file json dan melakukan update data
                for row in data:
                    row['flag'] = 'update'
                    bukajson.seek(0)
                    json.dump(data, bukajson, indent=4)
                    bukajson.truncate()
            print("Update Status")
            #mencetak tulisan
            openfile = open("bank_json.json", "r")
            data = json.load(openfile)
            #membuka file json
            for row in data:
                    if row['flag'] == 'update':
                        print("Terdapat Perubahan Status Transaksi")
                        #mencetakan tulisan
                        transaksi = row['id_transaksi']
                        status = row['status']
                        #mengambil status dalam row json
                        cur.execute("update tb_transaksi set status='%s' where id_transaksi='%s'" % (status,transaksi))
                        #untuk melakukan update pada tb_transaksi
                        conn.commit()
                        updatestatustoko()
            def inserttoko(id_transaksi, id_pembeli, no_rek, tgl_transaksi, total_transaksi, status):
                # fungsi untuk membaca paramenter inserttoko
                list_data = []
                with open("toko_json.json", "r", encoding='utf-8')as outfile:
                    #untuk membuka file json toko_json
                    try:
                        data = json.load(outfile)
                    except:
                        data = []
                new_entry = {'id_transaksi': id_transaksi, 'id_pembeli': id_pembeli, 'no_rek': no_rek,
                             'tanggal': str(tgl_transaksi), 'total_transaksi': total_transaksi, 'status': status,
                             'flag': 'update'}
                # untuk memasukan data ke json
                list_data.append(new_entry)
                with open("toko_json.json", "w", encoding='utf-8')as outfile:
                    json.dump(data + list_data, outfile, indent=4)
                    #untuk membuka file json toko_json
            lanjut = True
            while lanjut:
                cur.execute("select max(id_transaksi) from tb_transaksi")
                #untuk menyeleksi data
                maxdatatransaksi = cur.fetchone()
                cur.execute("select *from tb_transaksi")
                toko = cur.fetchall()
                lanjut = False

                with open("toko_json.json", "r", encoding='utf-8')as outfile:
                    try:
                        data = json.load(outfile)
                    except:
                        data = []
                    if (len(toko) > len(data)):
                        cur.execute("select id_transaksi, id_pembeli, no_rek, tgl_transaksi, total_transaksi, status from tb_transaksi where id_transaksi='%s'" % (maxdatatransaksi))
                        for row1 in cur.fetchall():
                            id_transaksi, id_pembeli, no_rek, tgl_transaksi, total_transaksi, status = row1
                            inserttoko(id_transaksi, id_pembeli, no_rek, tgl_transaksi, total_transaksi, status)
                            #untuk menulis ke File Json
                            print("Update status suksess sekali")
                            drop = dropbox.Dropbox("9EXUZ0tRCwAAAAAAAAAADFCMfVabePA38B8cUt6HZc2Tq7dGX_5fAMKlv30rJoIm");
                            with open("toko_json.json", "rb") as toko_dropbox:
                                drop.files_upload(toko_dropbox.read(), "/Aplikasi/toko_json.json", mode=dropbox.files.WriteMode("overwrite"));
                                print("berhasil Upload Updatean data toko_json ke Dropbox")
                                #untuk mengupload file json ke dropbox
except:
    print('error klee')
    # untuk mencetak tulisan jika terjadi kesalahan